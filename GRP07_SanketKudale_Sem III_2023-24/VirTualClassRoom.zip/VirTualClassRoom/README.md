LogIn/SignUp Page : 

![Screenshot_2023-12-20-22-34-28-891_com linkedin android](https://github.com/TejasKalokh/VirTualClassRoom/assets/105121807/3a988f18-7b50-4842-b790-06d077727c99)

HomePage : 

![Screenshot_2023-12-20-22-34-33-701_com linkedin android](https://github.com/TejasKalokh/VirTualClassRoom/assets/105121807/5a2ee758-dc2b-43e3-b12e-f748645c38e2)

MainClassRoom Interface: 

![Screenshot_2023-12-20-22-34-43-679_com linkedin android](https://github.com/TejasKalokh/VirTualClassRoom/assets/105121807/cbab8d4a-b106-42e5-990b-db6af060db0c)

Todolist : 

![Screenshot_2023-12-20-22-34-37-299_com linkedin android](https://github.com/TejasKalokh/VirTualClassRoom/assets/105121807/4b7acf24-a056-4679-a5b2-a21736fd1142)

